'use strict';

module.exports = function(Readedofmsg) {

};
