'use strict';

module.exports = function(Customerblockcmd) {

};
